$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-2 Minus.feature");
formatter.feature({
  "name": "minus",
  "description": "  I want to use minus operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Subtraction",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e minus \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "10",
        "20",
        "-10"
      ]
    },
    {
      "cells": [
        "222",
        "111",
        "111"
      ]
    },
    {
      "cells": [
        "100",
        "-78",
        "178"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Subtraction",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 minus 20",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.minus(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result -10",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [-10, -10]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result -10(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-2 Minus.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Subtraction",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "222 minus 111",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.minus(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 111",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [111, 111]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result 111(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-2 Minus.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Subtraction",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "100 minus -78",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.minus(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 178",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [178, 178]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result 178(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-2 Minus.feature:7)\r\n",
  "status": "failed"
});
});