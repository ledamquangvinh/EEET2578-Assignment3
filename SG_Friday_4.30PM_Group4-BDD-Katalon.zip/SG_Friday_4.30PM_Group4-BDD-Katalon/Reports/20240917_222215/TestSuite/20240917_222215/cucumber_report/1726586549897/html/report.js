$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-7 GCD.feature");
formatter.feature({
  "name": "gcd",
  "description": "  I want to use GCD operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "GCD",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e gcd \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "92",
        "312",
        "4"
      ]
    },
    {
      "cells": [
        "222",
        "111",
        "111"
      ]
    }
  ]
});
formatter.scenario({
  "name": "GCD",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "92 gcd 312",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.gcd(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 4",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [4, 4]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result 4(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-7 GCD.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "GCD",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "222 gcd 111",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.gcd(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 111",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [111, 111]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result 111(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-7 GCD.feature:7)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "name": "Illegal GCD",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e illegal gcd \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the Exception \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "0",
        "0",
        "\"GCD(0, 0) is undefined\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "Illegal GCD",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "0 illegal gcd 0",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aIllegalGCDB(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the Exception \"GCD(0, 0) is undefined\"",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheException(String)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (String, String) values: [GCD(0, 0) is undefined, GCD(0, 0) is undefined]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheException(StepDefinition.groovy:197)\r\n\tat ✽.I get the Exception \"GCD(0, 0) is undefined\"(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-7 GCD.feature:17)\r\n",
  "status": "failed"
});
});