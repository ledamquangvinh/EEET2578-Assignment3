$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-6 Power.feature");
formatter.feature({
  "name": "power",
  "description": "  I want to use power operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e to the power of \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e in Double",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "10",
        "5",
        "100000"
      ]
    },
    {
      "cells": [
        "8",
        "3",
        "512"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 to the power of 5",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.power(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 100000 in Double",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "name": "Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "8 to the power of 3",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.power(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 512 in Double",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenarioOutline({
  "name": "Negative Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e to the power of \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e in Double with \u003cprecision\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result",
        "precision"
      ]
    },
    {
      "cells": [
        "10",
        "-5",
        "0.000001",
        "5"
      ]
    },
    {
      "cells": [
        "27",
        "-3",
        "0.00000508",
        "8"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Negative Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 to the power of -5",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.power(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 0.000001 in Double with 5",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(double,int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Double, Double, Integer) values: [0.0, 1.0E-6, 5]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:133)\r\n\tat ✽.I get the result 0.000001 in Double with 5(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-6 Power.feature:17)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Negative Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "27 to the power of -3",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.power(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 0.00000508 in Double with 8",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(double,int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Double, Double, Integer) values: [0.0, 5.08E-6, 8]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:133)\r\n\tat ✽.I get the result 0.00000508 in Double with 8(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-6 Power.feature:17)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "name": "Error Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "illegal \u003ca\u003e to the power of \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the Exception \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "0",
        "-10",
        "\"Undefined for 0^(negative number)\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "Error Exponentiation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "illegal 0 to the power of -10",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.illegalPower(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the Exception \"Undefined for 0^(negative number)\"",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheException(String)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (String, String) values: [Undefined for 0^(negative number), Undefined for 0^(negative number)]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheException(StepDefinition.groovy:197)\r\n\tat ✽.I get the Exception \"Undefined for 0^(negative number)\"(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-6 Power.feature:27)\r\n",
  "status": "failed"
});
});