$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-9 Fibonacci.feature");
formatter.feature({
  "name": "fibonacci",
  "description": "  I want to use add operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "fibonacci number of \u003ca\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e in Long",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "result"
      ]
    },
    {
      "cells": [
        "15",
        "610"
      ]
    },
    {
      "cells": [
        "1",
        "1"
      ]
    },
    {
      "cells": [
        "0",
        "0"
      ]
    },
    {
      "cells": [
        "50",
        "12586269025"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "fibonacci number of 15",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.fibonacci(Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 610 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Long, Long) values: [610, 610]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInLong(StepDefinition.groovy:138)\r\n\tat ✽.I get the result 610 in Long(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-9 Fibonacci.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "fibonacci number of 1",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.fibonacci(Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 1 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Long, Long) values: [1, 1]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInLong(StepDefinition.groovy:138)\r\n\tat ✽.I get the result 1 in Long(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-9 Fibonacci.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "fibonacci number of 0",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.fibonacci(Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 0 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Long, Long) values: [0, 0]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInLong(StepDefinition.groovy:138)\r\n\tat ✽.I get the result 0 in Long(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-9 Fibonacci.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "fibonacci number of 50",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.fibonacci(Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 12586269025 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Long, Long) values: [12586269025, 12586269025]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInLong(StepDefinition.groovy:138)\r\n\tat ✽.I get the result 12586269025 in Long(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-9 Fibonacci.feature:7)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "name": "Error Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "illegal fibonacci number of \u003ca\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the Exception \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "result"
      ]
    },
    {
      "cells": [
        "-1",
        "\"Fibonacci cannot be calculated for negative numbers\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "Error Fibonacci",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "illegal fibonacci number of -1",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aIllegalFibonacci(Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the Exception \"Fibonacci cannot be calculated for negative numbers\"",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheException(String)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (String, String) values: [Fibonacci cannot be calculated for negative numbers, Fibonacci cannot be calculated for negative numbers]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheException(StepDefinition.groovy:197)\r\n\tat ✽.I get the Exception \"Fibonacci cannot be calculated for negative numbers\"(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-9 Fibonacci.feature:19)\r\n",
  "status": "failed"
});
});