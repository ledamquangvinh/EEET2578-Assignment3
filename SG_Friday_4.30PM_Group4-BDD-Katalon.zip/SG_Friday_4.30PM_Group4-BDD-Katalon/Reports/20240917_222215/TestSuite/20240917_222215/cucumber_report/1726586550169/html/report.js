$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-8 LCM.feature");
formatter.feature({
  "name": "lcm",
  "description": "  I want to use LCM operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e lcm \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "4",
        "6",
        "12"
      ]
    },
    {
      "cells": [
        "222",
        "111",
        "222"
      ]
    }
  ]
});
formatter.scenario({
  "name": "LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "4 lcm 6",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.lcm(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 12",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [12, 12]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result 12(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-8 LCM.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "222 lcm 111",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.lcm(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 222",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (Integer, Integer) values: [222, 222]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:123)\r\n\tat ✽.I get the result 222(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-8 LCM.feature:7)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "name": "Illegal LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e illegal lcm \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the Exception \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "0",
        "0",
        "\"LCM(0, 0) is undefined\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "Illegal LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "0 illegal lcm 0",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aIllegalLCMB(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the Exception \"LCM(0, 0) is undefined\"",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheException(String)"
});
formatter.result({
  "error_message": "groovy.lang.MissingMethodException: No signature of method: calculator.StepDefinition.assertEquals() is applicable for argument types: (String, String) values: [LCM(0, 0) is undefined, LCM(0, 0) is undefined]\r\n\tat org.codehaus.groovy.runtime.ScriptBytecodeAdapter.unwrap(ScriptBytecodeAdapter.java:70)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyGuardsFiltersAndSignatures.unwrap(IndyGuardsFiltersAndSignatures.java:160)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheException(StepDefinition.groovy:197)\r\n\tat ✽.I get the Exception \"LCM(0, 0) is undefined\"(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-8 LCM.feature:17)\r\n",
  "status": "failed"
});
});