$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-8 LCM.feature");
formatter.feature({
  "name": "lcm",
  "description": "  I want to use LCM operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e lcm \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "4",
        "6",
        "12"
      ]
    },
    {
      "cells": [
        "222",
        "111",
        "222"
      ]
    }
  ]
});
formatter.scenario({
  "name": "LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "4 lcm 6",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.lcm(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 12",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "222 lcm 111",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.lcm(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 222",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "Illegal LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e illegal lcm \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the Exception \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "0",
        "0",
        "\"LCM(0, 0) is undefined\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "Illegal LCM",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "0 illegal lcm 0",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aIllegalLCMB(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the Exception \"LCM(0, 0) is undefined\"",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheException(String)"
});
formatter.result({
  "status": "passed"
});
});