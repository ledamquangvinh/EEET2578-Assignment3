$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-3 Multiply.feature");
formatter.feature({
  "name": "multiply",
  "description": "  I want to use multiply operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Multiplication",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e multiply \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e in Long",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "10",
        "20",
        "200"
      ]
    },
    {
      "cells": [
        "92",
        "-19",
        "-1748"
      ]
    },
    {
      "cells": [
        "12",
        "-19",
        "-228"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Multiplication",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 multiply 20",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.multiply(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 200 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Multiplication",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "92 multiply -19",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.multiply(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result -1748 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Multiplication",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "12 multiply -19",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.multiply(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result -228 in Long",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInLong(long)"
});
formatter.result({
  "status": "passed"
});
});