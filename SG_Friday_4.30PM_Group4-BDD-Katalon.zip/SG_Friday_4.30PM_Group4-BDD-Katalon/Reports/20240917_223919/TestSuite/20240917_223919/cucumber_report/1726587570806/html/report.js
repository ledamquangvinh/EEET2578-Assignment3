$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-1 Add.feature");
formatter.feature({
  "name": "add",
  "description": "    I want to use add operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Addition",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e plus \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "10",
        "20",
        "30"
      ]
    },
    {
      "cells": [
        "123",
        "456",
        "579"
      ]
    },
    {
      "cells": [
        "177",
        "13",
        "190"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Addition",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 plus 20",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aPlusB(int,int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 30",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Addition",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "123 plus 456",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aPlusB(int,int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 579",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Addition",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "177 plus 13",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aPlusB(int,int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 190",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "status": "passed"
});
});