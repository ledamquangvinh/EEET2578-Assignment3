$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-5 Modulus.feature");
formatter.feature({
  "name": "modulus",
  "description": "  I want to use modulus operator",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Modulation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e modulus \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the result \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "10",
        "20",
        "10"
      ]
    },
    {
      "cells": [
        "222",
        "111",
        "111"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Modulation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 modulus 20",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aModulusB(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 10",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "java.lang.AssertionError: expected:\u003c0\u003e but was:\u003c10\u003e\r\n\tat org.junit.Assert.fail(Assert.java:89)\r\n\tat org.junit.Assert.failNotEquals(Assert.java:835)\r\n\tat org.junit.Assert.assertEquals(Assert.java:647)\r\n\tat org.junit.Assert.assertEquals(Assert.java:633)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:124)\r\n\tat ✽.I get the result 10(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-5 Modulus.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "name": "Modulation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "222 modulus 111",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aModulusB(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the result 111",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheResultResultInDouble(int)"
});
formatter.result({
  "error_message": "java.lang.AssertionError: expected:\u003c0\u003e but was:\u003c111\u003e\r\n\tat org.junit.Assert.fail(Assert.java:89)\r\n\tat org.junit.Assert.failNotEquals(Assert.java:835)\r\n\tat org.junit.Assert.assertEquals(Assert.java:647)\r\n\tat org.junit.Assert.assertEquals(Assert.java:633)\r\n\tat org.codehaus.groovy.vmplugin.v8.IndyInterface.fromCache(IndyInterface.java:318)\r\n\tat calculator.StepDefinition.iGetTheResultResultInDouble(StepDefinition.groovy:124)\r\n\tat ✽.I get the result 111(C:/Users/tugia/Katalon Studio/A3-Calculator/Include/features/CAL-5 Modulus.feature:7)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "name": "Illegal Modulation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.step({
  "name": "\u003ca\u003e illegal modulus \u003cb\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "I get the Exception \u003cresult\u003e",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "a",
        "b",
        "result"
      ]
    },
    {
      "cells": [
        "10",
        "0",
        "\"Modular cannot be zero\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "Illegal Modulation",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "I run the code",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.iRunTheCode()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "10 illegal modulus 0",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.aIllegalModulusB(Integer,Integer)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I get the Exception \"Modular cannot be zero\"",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.iGetTheException(String)"
});
formatter.result({
  "status": "passed"
});
});