<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_294 xovietnghetinh</name>
   <tag></tag>
   <elementGuidId>f2fad6ce-7114-464d-a043-05853179bf16</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(14) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/table/tbody/tr[14]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;294 xovietnghetinh&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>5e398df7-ef6c-4a16-8aa7-e87e90548ce8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>294 xovietnghetinh</value>
      <webElementGuid>b43b297f-5d3f-4da2-9223-38242f98d409</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/table[1]/tbody[1]/tr[14]/td[2]</value>
      <webElementGuid>ad9b9fd8-245a-4ece-a5b5-35d1bb9cc518</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/table/tbody/tr[14]/td[2]</value>
      <webElementGuid>9b1025f5-641b-4fc5-aafd-2c5b4b8047c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address 1:'])[2]/following::td[1]</value>
      <webElementGuid>30815781-c2fe-487a-beca-5ca6ee7880a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ngo'])[2]/following::td[2]</value>
      <webElementGuid>5b807383-e881-44f1-992c-e3c1a30fce91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address 2:'])[2]/preceding::td[1]</value>
      <webElementGuid>91890e16-d274-4aaf-881b-45104c296dd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='City:'])[2]/preceding::td[3]</value>
      <webElementGuid>0fe1bdca-ca67-4792-b8d0-bd66c0ffa048</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[14]/td[2]</value>
      <webElementGuid>b639ed68-cfa2-45e5-89a0-af29a4bc6a2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '294 xovietnghetinh' or . = '294 xovietnghetinh')]</value>
      <webElementGuid>608802b9-9e78-412a-a5db-2aa34ef34271</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
