<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Expiry Date (MMYYYY)</name>
   <tag></tag>
   <elementGuidId>6046e722-f1d1-44f6-a076-da7ddcc065bf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(4) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/form/table/tbody/tr[4]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Expiry Date (MM/YYYY):&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>8c9ba8fc-b4ec-4f63-8db6-4d89c746976a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Expiry Date (MM/YYYY):</value>
      <webElementGuid>675c46dc-c495-45b6-9810-02e61f88596c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/form[1]/table[1]/tbody[1]/tr[4]/td[1]</value>
      <webElementGuid>f0529e32-7068-4496-b5e2-ea2255f728b4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/form/table/tbody/tr[4]/td</value>
      <webElementGuid>fd54980c-c1ea-4e9f-a7c7-7568e4203c61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Card Number:'])[1]/following::td[2]</value>
      <webElementGuid>78e9fb0a-d4f0-4a29-974d-493a6440c57e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Billing Address'])[1]/preceding::td[2]</value>
      <webElementGuid>17a86de9-83a1-4b58-8cfb-6ae4104a2b20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='First name:'])[1]/preceding::td[2]</value>
      <webElementGuid>7ac9d689-7f8b-4fee-9c34-a4c7e230d58c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Expiry Date (MM/YYYY):']/parent::*</value>
      <webElementGuid>8d0ad525-92fc-47ed-906c-29107dc5cecf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td</value>
      <webElementGuid>ef2f50c2-113a-4c81-98cf-f685489332b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Expiry Date (MM/YYYY):' or . = 'Expiry Date (MM/YYYY):')]</value>
      <webElementGuid>964684c7-2a99-4bde-b532-29a9e8124a94</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
