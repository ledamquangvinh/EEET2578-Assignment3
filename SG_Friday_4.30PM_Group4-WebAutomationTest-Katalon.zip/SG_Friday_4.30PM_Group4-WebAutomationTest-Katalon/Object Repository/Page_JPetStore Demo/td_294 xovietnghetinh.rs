<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_294 xovietnghetinh</name>
   <tag></tag>
   <elementGuidId>61744d63-a682-4227-b238-73b7c3f1b607</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(14) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/table/tbody/tr[14]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;294 xovietnghetinh&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>76d85c84-4412-4750-8640-fc94b3ee807e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>294 xovietnghetinh</value>
      <webElementGuid>adc7e0de-0e87-4edd-84f2-a31938a6bb64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/table[1]/tbody[1]/tr[14]/td[2]</value>
      <webElementGuid>4dd43dcc-c774-4146-b7a1-1358d90c6fed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/table/tbody/tr[14]/td[2]</value>
      <webElementGuid>466ab59e-5067-4dba-9433-1c108fb79ce1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address 1:'])[2]/following::td[1]</value>
      <webElementGuid>8ccc1520-4611-485e-9054-0c69b58ab64e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ngo'])[2]/following::td[2]</value>
      <webElementGuid>e6634ea6-36f2-486d-afb8-c036b0c4ddcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address 2:'])[2]/preceding::td[1]</value>
      <webElementGuid>bd875421-6232-4269-b503-4a113c638f57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='City:'])[2]/preceding::td[3]</value>
      <webElementGuid>148bdc98-c84d-42ed-99e6-fa5a69edb26e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='294 xovietnghetinh']/parent::*</value>
      <webElementGuid>eba60b34-9b57-44a0-84b4-bb5f3cb285e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[14]/td[2]</value>
      <webElementGuid>50737334-fa06-41de-b325-e47f7b2e4bb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '294 xovietnghetinh' or . = '294 xovietnghetinh')]</value>
      <webElementGuid>c9bf7f64-e950-4811-a7b7-22cea2de5ce9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
