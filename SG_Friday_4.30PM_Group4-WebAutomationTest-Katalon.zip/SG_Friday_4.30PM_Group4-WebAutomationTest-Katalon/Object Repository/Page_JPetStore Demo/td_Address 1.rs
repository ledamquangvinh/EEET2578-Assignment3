<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Address 1</name>
   <tag></tag>
   <elementGuidId>4f7caa0d-4e4c-4083-8ee9-a15e660217bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(8) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/form/table/tbody/tr[8]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Address 1:&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>95dda086-1006-41ba-8c7b-8f73fd62e1f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Address 1:</value>
      <webElementGuid>7124ccc5-e622-4fd6-92e0-e760dc5918aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/form[1]/table[1]/tbody[1]/tr[8]/td[1]</value>
      <webElementGuid>9d466b51-e54a-4667-9724-a219503fb9dc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/form/table/tbody/tr[8]/td</value>
      <webElementGuid>26bfab38-a52f-4840-a100-4cdfb9d46e50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last name:'])[1]/following::td[2]</value>
      <webElementGuid>9b64cfa1-9d68-4d91-8ebb-d7757caa46b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='First name:'])[1]/following::td[4]</value>
      <webElementGuid>55592397-987b-49f1-88ed-2a405403918f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address 2:'])[1]/preceding::td[2]</value>
      <webElementGuid>bf170cce-fd99-4fe1-b285-34a8d96f915f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='City:'])[1]/preceding::td[4]</value>
      <webElementGuid>c9fa4d5a-0b4d-45b4-ae7f-0de657214140</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Address 1:']/parent::*</value>
      <webElementGuid>56b95219-f6e2-4f61-bf44-9abf3eddfac0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[8]/td</value>
      <webElementGuid>002ae9d0-3a6e-4c23-833a-54587a9bcad8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Address 1:' or . = 'Address 1:')]</value>
      <webElementGuid>acba08fe-65ad-4328-b0a7-9a1ae5d44e84</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
