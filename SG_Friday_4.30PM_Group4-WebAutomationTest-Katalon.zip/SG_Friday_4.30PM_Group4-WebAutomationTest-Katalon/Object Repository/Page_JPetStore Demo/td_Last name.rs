<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Last name</name>
   <tag></tag>
   <elementGuidId>fbb8adaa-635d-49cc-b015-91fed213e962</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>table:nth-of-type(2) > tbody > tr:nth-of-type(2) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/form/table[2]/tbody/tr[2]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Last name:&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>e62ed9bd-8283-4e88-9b8d-60796c2fc6be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Last name:</value>
      <webElementGuid>90045daa-8f51-4452-a856-5dfd42f5b943</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/form[1]/table[2]/tbody[1]/tr[2]/td[1]</value>
      <webElementGuid>3e0278e6-c7df-4e43-b26c-9a18609eb0a5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/form/table[2]/tbody/tr[2]/td</value>
      <webElementGuid>6426ec2f-65dd-4d29-9d29-a3ddd1bc4da2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='First name:'])[1]/following::td[2]</value>
      <webElementGuid>ddae88a3-9fb2-4c75-9ca8-e5c01519dec5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Information'])[1]/following::td[3]</value>
      <webElementGuid>c543caaf-e423-4d13-805b-1bfe9bfe0f35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email:'])[1]/preceding::td[2]</value>
      <webElementGuid>a084ef6d-bf92-4395-a217-6a715cbba7bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Phone:'])[1]/preceding::td[4]</value>
      <webElementGuid>baac7def-775a-450c-b353-62b7ad800993</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Last name:']/parent::*</value>
      <webElementGuid>fc27944b-45e6-4739-86c0-c817d5385f0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/tbody/tr[2]/td</value>
      <webElementGuid>591ef05a-3622-4064-bd02-b4850c03a197</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Last name:' or . = 'Last name:')]</value>
      <webElementGuid>e158272a-6ef1-43b5-bf40-a651f611a904</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
