<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Add to Cart</name>
   <tag></tag>
   <elementGuidId>45cf8398-3a2a-42eb-8369-df92d876cfce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.Button</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/table/tbody/tr[2]/td[5]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Add to Cart&quot;i] >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9cf7967b-2769-4b55-9e80-48991798f50e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-4</value>
      <webElementGuid>f90b1bf9-5953-460d-b07e-f71b0e0afebf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Button</value>
      <webElementGuid>c33f24d2-507d-4716-848b-2e1787ba463d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to Cart</value>
      <webElementGuid>df4adf86-76a3-4ba2-a035-5b915a414ab3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/table[1]/tbody[1]/tr[2]/td[5]/a[@class=&quot;Button&quot;]</value>
      <webElementGuid>4f7803f3-d18b-485f-b394-7f9a4601d08e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/table/tbody/tr[2]/td[5]/a</value>
      <webElementGuid>53f0fc56-cbe4-4f44-8db0-1a0038c6a2ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Add to Cart')]</value>
      <webElementGuid>38016bf1-1fdb-4beb-baa5-e93c84e8a907</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$18.50'])[1]/following::a[1]</value>
      <webElementGuid>6a504849-2a25-4d25-ab19-9048422aeb60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EST-5'])[1]/preceding::a[1]</value>
      <webElementGuid>8e78243e-02a5-49f0-8e88-040c4ac97687</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FI-FW-01'])[2]/preceding::a[2]</value>
      <webElementGuid>3f400392-a9a8-4290-a14c-ae376991f0fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to Cart']/parent::*</value>
      <webElementGuid>9c0790ee-3070-4bc0-8c77-3aac513ac7db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-4')]</value>
      <webElementGuid>ee95613f-90eb-4992-b1d2-2a82feee17bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[5]/a</value>
      <webElementGuid>d020c912-03e1-4423-9670-10162d2496fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-4' and (text() = 'Add to Cart' or . = 'Add to Cart')]</value>
      <webElementGuid>2d072cef-fec9-418c-a2a0-7f8e3fdf90e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$125.50'])[1]/following::a[1]</value>
      <webElementGuid>e36e078c-c7c0-4923-8575-750a65f9061c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EST-27'])[1]/preceding::a[1]</value>
      <webElementGuid>b96d8d92-7c80-4436-ba11-0f256e935584</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='K9-CW-01'])[2]/preceding::a[2]</value>
      <webElementGuid>1f6695de-1d32-459c-acf3-4fb68c3cb274</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-26')]</value>
      <webElementGuid>fe8c82b1-bb26-416d-8e55-3261f9897e24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-26' and (text() = 'Add to Cart' or . = 'Add to Cart')]</value>
      <webElementGuid>ef59dc14-3c0e-401e-b21f-c7f648534932</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$58.50'])[1]/following::a[1]</value>
      <webElementGuid>24e9d4b3-4ea6-42ce-bc35-df036d457391</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EST-15'])[1]/preceding::a[1]</value>
      <webElementGuid>27ff1322-44e6-41ab-9c1d-cd2b602d714c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FL-DSH-01'])[2]/preceding::a[2]</value>
      <webElementGuid>377cf319-84e5-4933-8527-fb6fb0ada868</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-14')]</value>
      <webElementGuid>8cb9c50b-6c8b-4545-bd7a-d84d77499803</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-14' and (text() = 'Add to Cart' or . = 'Add to Cart')]</value>
      <webElementGuid>680b505a-ce27-4658-b77e-5b214e68f7f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OctoPerf'])[1]/preceding::a[1]</value>
      <webElementGuid>05642500-44a7-4bcc-89c5-1dd10caea89c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-8')]</value>
      <webElementGuid>877f3b9d-bfc5-47ec-869e-df7aee1f0c0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-8' and (text() = 'Add to Cart' or . = 'Add to Cart')]</value>
      <webElementGuid>4c54afdd-9d3e-4997-967e-2fed4cf812b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EST-7'])[1]/preceding::a[1]</value>
      <webElementGuid>47ded5ba-e9e8-4bc8-b666-8f6ea53e8771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='K9-BD-01'])[2]/preceding::a[2]</value>
      <webElementGuid>63c108bb-a0bc-4e0b-8a37-2175b9c846fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-6')]</value>
      <webElementGuid>929a52e2-df6b-4814-862a-e698d1a454cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Cart.action?addItemToCart=&amp;workingItemId=EST-6' and (text() = 'Add to Cart' or . = 'Add to Cart')]</value>
      <webElementGuid>513640c4-9ab7-4ead-ba6c-87186b709ef4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
