<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign In</name>
   <tag></tag>
   <elementGuidId>db2a4495-c7a5-46d8-aa6f-f7c0a31f33f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='MenuContent']/a[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Sign In&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8a034c61-3702-4147-8be6-5d42a0af9679</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/actions/Account.action;jsessionid=5275252A5257C3B3C7BAA204CE32FC26?signonForm=</value>
      <webElementGuid>3a44d0b2-959b-4955-89f4-55d59252a1d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign In</value>
      <webElementGuid>60e58eca-2d7d-4729-9a68-4dc0b59a77c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MenuContent&quot;)/a[2]</value>
      <webElementGuid>7dcb6f58-6d46-4800-856b-e37fac584d01</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='MenuContent']/a[2]</value>
      <webElementGuid>e41e7b57-2a0a-43fa-afa2-df041c02489b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Sign In')]</value>
      <webElementGuid>668aa314-500c-4214-843a-4280b881c32f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='?'])[1]/preceding::a[1]</value>
      <webElementGuid>9265fb58-b6cf-4733-a847-8050a8f92706</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign In']/parent::*</value>
      <webElementGuid>fa8b1199-ecbd-4b81-80d7-de609cdba616</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Account.action;jsessionid=5275252A5257C3B3C7BAA204CE32FC26?signonForm=')]</value>
      <webElementGuid>a17a9118-786a-4638-be69-f537f6b85c12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]</value>
      <webElementGuid>72c183fe-a6e3-4e50-9ef0-dc4f5d14104f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Account.action;jsessionid=5275252A5257C3B3C7BAA204CE32FC26?signonForm=' and (text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>670eb40f-5758-43c4-a97e-4a17763e3bb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Account.action;jsessionid=7E070300D2FBA8BB27AE25E4132D706B?signonForm=')]</value>
      <webElementGuid>8dd5d944-8a1d-4da0-b16c-728d2e68db55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Account.action;jsessionid=7E070300D2FBA8BB27AE25E4132D706B?signonForm=' and (text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>3db46e05-38cf-4d5c-9ccc-e4eae20ddfaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Account.action;jsessionid=5C2391331D782FB13F329E75E355812D?signonForm=')]</value>
      <webElementGuid>038fd0cf-0d74-43eb-bd18-44054c23b97b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Account.action;jsessionid=5C2391331D782FB13F329E75E355812D?signonForm=' and (text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>5b6fe1b8-19fe-43e7-929c-6c9d29b75fdb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Account.action;jsessionid=7227AC325BAF7343B42F2C535737F6AA?signonForm=')]</value>
      <webElementGuid>eb62b364-0f02-4466-b432-07c76f4cfac0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Account.action;jsessionid=7227AC325BAF7343B42F2C535737F6AA?signonForm=' and (text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>823891a9-ff2d-47fe-a1f3-3fd80e89f6d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Account.action;jsessionid=FBA0989DE4773814C8DD58808E758D51?signonForm=')]</value>
      <webElementGuid>f9459124-96de-4089-b358-fc25fdb1e16a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Account.action;jsessionid=FBA0989DE4773814C8DD58808E758D51?signonForm=' and (text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>aabe23e6-82f7-4d76-a02d-49ca58a6b20c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/actions/Account.action;jsessionid=BF267AA9E25FD740AC633FD9CF0A7162?signonForm=')]</value>
      <webElementGuid>8505839c-a2fe-4f69-b6eb-37e1c0cf2343</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/actions/Account.action;jsessionid=BF267AA9E25FD740AC633FD9CF0A7162?signonForm=' and (text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>b527aa28-74f2-48aa-9641-d4fc84f5b5d8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
