<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Shopping CartItem IDProduct IDDescripti_499dba</name>
   <tag></tag>
   <elementGuidId>a95e6ed1-146b-409b-83fb-54bc12aeb176</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#Catalog</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#Catalog</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b7ba5bef-431f-47dc-b581-b9cc4f91dc43</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>Catalog</value>
      <webElementGuid>0790a76d-2173-43b9-badf-1bc4f577baeb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



Shopping Cart

	
		
			Item ID
			Product ID
			Description
			In Stock?
			Quantity
			List Price
			Total Cost
			 
		

		

		
			
				EST-10
				K9-DL-01
				Spotted Adult Female 
				 
				 Dalmation
				true
				
				$18.50
				$185,000,000.00
				Remove
			
		
		
			Sub Total: $185,000,000.00 
			 
		
	

 
	Proceed to Checkout



  


 
</value>
      <webElementGuid>a8543c4f-cd70-4958-a86a-a2dfad46b168</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)</value>
      <webElementGuid>e62bf7ab-96a9-479d-bde9-9892a247817f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='Catalog']</value>
      <webElementGuid>0928332d-edb6-4ed3-9d66-ef62191d51de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div[2]</value>
      <webElementGuid>8c57280c-6168-4f59-baf4-6aec67d18d41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Return to Main Menu'])[1]/following::div[1]</value>
      <webElementGuid>8a209277-89e2-41da-bc6d-497d29bb4d28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='?'])[1]/following::div[7]</value>
      <webElementGuid>6b1a9123-94af-435e-86b9-aec5c0575b8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]</value>
      <webElementGuid>e9d5558b-3ce9-4e4d-a9ae-4c23b0a49fe9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'Catalog' and (text() = '



Shopping Cart

	
		
			Item ID
			Product ID
			Description
			In Stock?
			Quantity
			List Price
			Total Cost
			 
		

		

		
			
				EST-10
				K9-DL-01
				Spotted Adult Female 
				 
				 Dalmation
				true
				
				$18.50
				$185,000,000.00
				Remove
			
		
		
			Sub Total: $185,000,000.00 
			 
		
	

 
	Proceed to Checkout



  


 
' or . = '



Shopping Cart

	
		
			Item ID
			Product ID
			Description
			In Stock?
			Quantity
			List Price
			Total Cost
			 
		

		

		
			
				EST-10
				K9-DL-01
				Spotted Adult Female 
				 
				 Dalmation
				true
				
				$18.50
				$185,000,000.00
				Remove
			
		
		
			Sub Total: $185,000,000.00 
			 
		
	

 
	Proceed to Checkout



  


 
')]</value>
      <webElementGuid>333110ac-36a5-4181-b7db-814d4ca8e54f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
