<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_First name</name>
   <tag></tag>
   <elementGuidId>6629b777-c986-4ca5-9ffa-75b4d9969459</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>table:nth-of-type(2) > tbody > tr > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/form/table[2]/tbody/tr/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;First name:&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>f95a1f57-17ee-423d-8022-9bd3e2c046cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>First name:</value>
      <webElementGuid>d483c72c-09d9-4590-a095-84971e7ae83f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/form[1]/table[2]/tbody[1]/tr[1]/td[1]</value>
      <webElementGuid>0a2c8f18-b5ff-4ef0-a96e-854c13d06ad2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/form/table[2]/tbody/tr/td</value>
      <webElementGuid>e5db2372-6b76-4ab7-a8f9-2a7b52301260</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Information'])[1]/following::td[1]</value>
      <webElementGuid>c2add059-8fd4-4fb9-bc75-231ff3d5b2e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Repeat password:'])[1]/following::td[2]</value>
      <webElementGuid>604b1cb1-3c14-425c-a813-ce3375e7997d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last name:'])[1]/preceding::td[2]</value>
      <webElementGuid>a36e9eff-1ca6-4f26-b498-5e601b84a243</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email:'])[1]/preceding::td[4]</value>
      <webElementGuid>9dd5b8cd-a1fd-44cd-a6c9-118ab731d167</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='First name:']/parent::*</value>
      <webElementGuid>abca5321-d0b7-4871-8fbd-8afdae77a068</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/tbody/tr/td</value>
      <webElementGuid>32dc97cb-ef77-4f4e-bdfb-a8138ea002f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'First name:' or . = 'First name:')]</value>
      <webElementGuid>0839b4b7-d685-495c-978b-b0aa8229dad1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
