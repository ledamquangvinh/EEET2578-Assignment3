<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Last name</name>
   <tag></tag>
   <elementGuidId>4cab4b5c-fbb4-4fa9-a1b9-048bd4114e89</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>table:nth-of-type(2) > tbody > tr:nth-of-type(2) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/form/table[2]/tbody/tr[2]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Last name:&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>14c61f88-ecde-4185-bced-68160d167269</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Last name:</value>
      <webElementGuid>6a0aec23-4314-48bd-9b6e-a7f624ab05c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/form[1]/table[2]/tbody[1]/tr[2]/td[1]</value>
      <webElementGuid>25b71e8f-a72b-462b-916d-8b1f4d446184</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/form/table[2]/tbody/tr[2]/td</value>
      <webElementGuid>d9a458b9-7ed1-4b9b-8f72-c320a606a94b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='First name:'])[1]/following::td[2]</value>
      <webElementGuid>c44ef512-7fab-4c65-ba01-e72099d1bf0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Information'])[1]/following::td[3]</value>
      <webElementGuid>d444873a-9a77-4b2b-8033-dc7c089223e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email:'])[1]/preceding::td[2]</value>
      <webElementGuid>eb8528f1-a89b-46db-be7c-cd7d9c7cad8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Phone:'])[1]/preceding::td[4]</value>
      <webElementGuid>400af980-4ab9-405a-b681-3ba57f8d0d71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Last name:']/parent::*</value>
      <webElementGuid>3d557229-e7d3-4f15-b58e-e3f6a941f477</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/tbody/tr[2]/td</value>
      <webElementGuid>82f55321-4cbd-4796-9b77-479d7c620464</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Last name:' or . = 'Last name:')]</value>
      <webElementGuid>4447cf65-d815-475e-a825-284410da6b2b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
