<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_First name</name>
   <tag></tag>
   <elementGuidId>1a525639-d556-4d50-bfb0-4cf422180fb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>table:nth-of-type(2) > tbody > tr > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Catalog']/form/table[2]/tbody/tr/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;First name:&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>2142044c-9a3d-458c-9622-24cb3cfc2c5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>First name:</value>
      <webElementGuid>83fc55b7-bf7e-4965-8a53-5e88bd3677e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Catalog&quot;)/form[1]/table[2]/tbody[1]/tr[1]/td[1]</value>
      <webElementGuid>a6f9f60e-2e58-43d2-9922-58f84674f00d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Catalog']/form/table[2]/tbody/tr/td</value>
      <webElementGuid>97e7dfca-379d-4294-802a-60251babaa98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Information'])[1]/following::td[1]</value>
      <webElementGuid>e3e86ddf-e0f9-4ef2-a531-a686f965773d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Repeat password:'])[1]/following::td[2]</value>
      <webElementGuid>068bcebb-965c-4e8a-a8a3-98bbd780c1d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last name:'])[1]/preceding::td[2]</value>
      <webElementGuid>9bcde9af-c554-4f10-a7cc-192b03ce16b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email:'])[1]/preceding::td[4]</value>
      <webElementGuid>549fd842-f0b8-4b85-af75-aa4e882f4d72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='First name:']/parent::*</value>
      <webElementGuid>6b66136e-ba6a-41fb-bae9-63581a9398e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/tbody/tr/td</value>
      <webElementGuid>1122d7ed-8762-430b-91ac-599e5b9dde6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'First name:' or . = 'First name:')]</value>
      <webElementGuid>aea14299-cf9c-4f7e-817f-767dbbc058c2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
